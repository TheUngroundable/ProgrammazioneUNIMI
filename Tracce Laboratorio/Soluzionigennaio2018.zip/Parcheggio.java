import java.util.*;
public class Parcheggio {

    // dim posto 1-10

    // posti max 100

    // due righe in input
    // -descrizione posti
    // -veicoli da smistare

    public static ArrayList<Integer> parcheggio=new ArrayList<Integer>();

    public static void main(String[] arg) {
        Scanner scan=new Scanner(System.in);
        // ipotizzo input corretto
        String dimensioni=scan.nextLine();
        String veicoli=scan.nextLine();

        // imposto dimensioni
        scan=new Scanner(dimensioni);
        while(scan.hasNextInt()) {
            int dim=scan.nextInt();
            if(dim>=1 && dim<=10) parcheggio.add(dim); //boxing
        }
        //System.out.print("prima: ");
        //System.out.println(parcheggio);

        // parcheggio i veicoli, rimuovo dall'arraylist i posti che man mano uso
        scan=new Scanner(veicoli);
        while(scan.hasNextInt()) {
            int dim=scan.nextInt();
            if(dim>=1 && dim<=10) {
                int where=parcheggio.indexOf(dim);
                if(where>=0) parcheggio.remove(where);
            }
        }
        //System.out.print("dopo: ");
        //System.out.println(parcheggio);

        for(Integer i: parcheggio) {
            System.out.print(i);
            System.out.print(" ");
        }
        System.out.println();
    }
}
