/**
Leggere parole da un file, il cui nome è dato sulla linea di comando

Per ogni parola

	- se è tutta maiuscola, stampare 'M'
	- se è tutta minuscola, stampare 'm'
	- se contiene almeno uno dei caratteri "< = > !", stampare 'B'
	- tutte le altre, stampare 'A'

	inoltre calcolare diff somma ascii rispetto alla precedente

*/
import java.util.*;
import java.io.*;

public class FiltroA {
    public static void main(String[] arg)
    throws Exception {
        Scanner sorgente=new Scanner(new File(arg[0]));
        String prec="";

        while(sorgente.hasNext()) {
            String token=sorgente.next();
            System.out.print(token);
            System.out.print(":");
            System.out.print(sumAscii(token)-sumAscii(prec));
            /*
            System.out.print(sumAscii(token));
            System.out.print(", ");
            System.out.print(prec!=null ? sumAscii(prec) : "");
            */
            System.out.print(",");
            if(allCaps(token))
                System.out.println("U"); // Upper
            else if(allSmall(token))
                System.out.println("L"); // Lower
            else if(containsSpecial(token))
                System.out.println("S"); // Special
            else
                System.out.println("O"); // Other

            prec=token;
        }
    }

    public static boolean allCaps(String s) {
        for(char c: s.toCharArray()) { // who cares for efficiency ;)
            if(!Character.isUpperCase(c)) return false;
        }
        return true;
    }

    public static boolean allSmall(String s) {
        for(char c: s.toCharArray()) { // who cares for efficiency ;)
            if(!Character.isLowerCase(c)) return false;
        }
        return true;
    }

    public static boolean containsSpecial(String s) {
        for(char c: s.toCharArray()) { // who cares for efficiency ;)
            if("<=>!".indexOf(c)>=0) return true;
        }
        return false;
    }

    public static int sumAscii(String s) {
        int sum=0;
        for(char c: s.toCharArray()) { // who cares for efficiency ;)
            sum+=c;
        }
        return sum;
    }
}
