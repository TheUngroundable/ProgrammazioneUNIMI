/**
 * Se questa classe compila senza errori vuol dire che i
 * NOMI di classi e metodi del vostro elaborato sono corretti, null'altro!
 *
 * Basta compilarla. Eseguire questo main non fornisce nessuna informazione!
 */
public class _CheckNomiClassiMetodi {
    public static void main(String[] args) {
        new CoefficienteBinomiale();
        new Parcheggio();

        int[] data = {1,1,3};
        Statistiche.frequenze(data);
        Statistiche.mediana(data);
    }
}
