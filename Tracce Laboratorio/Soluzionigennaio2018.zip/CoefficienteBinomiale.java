import java.util.*;

public class CoefficienteBinomiale {

    public static void main(String[] arg)
    throws Exception {
        int n=Integer.parseInt(arg[0]);
        int k=Integer.parseInt(arg[1]);
        System.out.println(binom(n,k));
    }

    public static int binom(int n,int k) {
        if(k==0) return 1;
        if(n==0) return 0;
        return binom(n-1,k-1)+binom(n-1,k);
    }
}
